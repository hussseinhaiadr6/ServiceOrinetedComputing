package deployment;

import java.io.File;
import java.rmi.RemoteException;

import com.sun.net.httpserver.Filter;


import deployment.TrainReservationStub.Reservation;

public class TestFiltering {
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
		TrainFilterStub hwp = new TrainFilterStub();
		deployment.TrainFilterStub.Filter s = new TrainFilterStub.Filter();
		s.setArrivalDate("2023-01-02");
		s.setArrivalStation("StationB");
		s.setDepartureDate("2023-01-01");
		s.setDepartureStation("StationA");
		s.setPassword("test3");
		s.setTickets("2");
		s.setTravelClass("FIRST");
		s.setUsername("test3");

		s.setUsername("test3");
		
		System.out.print(hwp.filter(s).get_return());
	}

}
