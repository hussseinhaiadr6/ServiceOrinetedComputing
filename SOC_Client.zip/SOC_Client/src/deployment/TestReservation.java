package deployment;

import java.rmi.RemoteException;

import deployment.TrainReservationStub.Reservation;

public class TestReservation {
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
		TrainReservationStub hwp = new TrainReservationStub();
		Reservation s = new Reservation();
		s.setOutboundTrainID("T001");
		s.setPassword("test4");
		s.setReturnTrainID("T004");
		s.setTickets("2");
		s.setTicketType("FLEXIBLE");
		s.setTravelClass("FIRST");
		s.setUsername("test4");
		
		System.out.print(hwp.reservation(s).get_return());
	}

}
